import React from 'react';

function footer(props) {
    return (
        <div className='footer'>
            
        </div>
    );
}

export default footer;