import React, { useState, useEffect } from "react";
import offer1 from '../assets/car1.jpeg';
import offer2 from '../assets/car2.jpeg';
import offer3 from '../assets/car3.jpeg';
import offer4 from '../assets/car4.jpeg';
import offer5 from '../assets/car5.jpeg';
import '../styles/lightbox.css';

function Description(props) {
    
  const images = [
    {
        png: offer1,
        thumbnail: offer1,
    },
    {
        png: offer2,
        thumbnail: offer3,
    },
    {
        png: offer3,
        thumbnail: offer3,
    },
    {
        png: offer4,
        thumbnail: offer5,
    },
  ]

    return (
      <>
      <h1>SHOE ME MONEY </h1>
      </>
    );
}

export default Description;