
import './App.css';
import Header from './component/header';
import Home from './pages/home';
import AutoListings from './pages/autoListings';
import ProductDetails from './pages/productDetails';
import Description from './component/description';
function App() {
  return (
    <div className="App">
          <Header />
          <ProductDetails />

    </div>
  );
}

export default App;
